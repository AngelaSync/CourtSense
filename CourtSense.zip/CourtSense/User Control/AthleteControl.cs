﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CourtSense.User_Control
{
    public partial class AthleteControl : UserControl
    {
        private bool suppressSelectionEvent = false;
        private const string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=CourtSenseDB;Trusted_Connection=True;";
        public AttendanceControl AttendanceControlRef { get; set; }

        public AthleteControl()
        {
            InitializeComponent();
            Load += AthleteControl_Load;
        }

        private void AthleteControl_Load(object sender, EventArgs e)
        {
            SetupDataGrid();
            WireEvents();
            LoadAthletes();
        }

        private void WireEvents()
        {
            txtBoxHeight.KeyPress += NumericOnly_KeyPress;
            txtBoxWeight.KeyPress += NumericOnly_KeyPress;

            // Remove previous handlers to prevent doubling
            btnAdd.Click -= btnAdd_Click;
            btnAdd.Click += btnAdd_Click;

            btnUpdate.Click -= btnUpdate_Click;
            btnUpdate.Click += btnUpdate_Click;

            btnRemove.Click -= btnRemove_Click;
            btnRemove.Click += btnRemove_Click;

            btnBrowse.Click -= btnBrowse_Click;
            btnBrowse.Click += btnBrowse_Click;

            btnClearFields.Click -= btnClearFields_Click;
            btnClearFields.Click += btnClearFields_Click;

            dataGridViewAthletes.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewAthletes.MultiSelect = false;
            dataGridViewAthletes.RowTemplate.Height = 60;
            dataGridViewAthletes.SelectionChanged -= DataGridViewAthletes_SelectionChanged;
            dataGridViewAthletes.SelectionChanged += DataGridViewAthletes_SelectionChanged;
        }

        private void SetupDataGrid()
        {
            dataGridViewAthletes.Columns.Clear();
            dataGridViewAthletes.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dataGridViewAthletes.Columns.Add("AthleteID", "Athlete ID");
            dataGridViewAthletes.Columns.Add("LastName", "Last Name");
            dataGridViewAthletes.Columns.Add("FirstName", "First Name");
            dataGridViewAthletes.Columns.Add("Age", "Age");
            dataGridViewAthletes.Columns.Add("Height", "Height (ft)");
            dataGridViewAthletes.Columns.Add("Weight", "Weight (lbs)");
            dataGridViewAthletes.Columns.Add("DOB", "Date of Birth");
            dataGridViewAthletes.Columns.Add("Status", "Status");
            dataGridViewAthletes.Columns.Add("Position", "Position");

            var imgCol = new DataGridViewImageColumn
            {
                Name = "ProfileImage",
                HeaderText = "Profile",
                Width = 60,
                ImageLayout = DataGridViewImageCellLayout.Zoom
            };
            dataGridViewAthletes.Columns.Add(imgCol);
            dataGridViewAthletes.RowTemplate.Height = 60;
        }

        private void NumericOnly_KeyPress(object sender, KeyPressEventArgs e)
        {
            TextBox txt = sender as TextBox;
            if (char.IsControl(e.KeyChar)) return;
            if (char.IsDigit(e.KeyChar)) return;
            if (e.KeyChar == '.' && !txt.Text.Contains(".")) return;
            e.Handled = true;
        }

        public void LoadAthletes()
        {
            suppressSelectionEvent = true;
            dataGridViewAthletes.Rows.Clear();

            try
            {
                using SqlConnection conn = new SqlConnection(ConnectionString);
                conn.Open();
                string query = @"SELECT AthleteID, LastName, FirstName, Age, Height, Weight, DOB, Status, Position, ProfileImage
                                 FROM Athletes ORDER BY LastName, FirstName";
                using SqlCommand cmd = new SqlCommand(query, conn);
                using SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Image img = null;
                    if (!reader.IsDBNull(9))
                    {
                        byte[] data = (byte[])reader[9];
                        using MemoryStream ms = new MemoryStream(data);
                        img = Image.FromStream(ms);
                    }

                    dataGridViewAthletes.Rows.Add(
                        reader.IsDBNull(0) ? "" : reader.GetString(0),
                        reader.IsDBNull(1) ? "" : reader.GetString(1),
                        reader.IsDBNull(2) ? "" : reader.GetString(2),
                        reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                        reader.IsDBNull(4) ? 0.0 : reader.GetDouble(4),
                        reader.IsDBNull(5) ? 0.0 : reader.GetDouble(5),
                        reader.IsDBNull(6) ? "" : reader.GetDateTime(6).ToShortDateString(),
                        reader.IsDBNull(7) ? "" : reader.GetString(7),
                        reader.IsDBNull(8) ? "" : reader.GetString(8),
                        img
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading athletes:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            suppressSelectionEvent = false;
            ClearFields();
            dataGridViewAthletes.ClearSelection();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Validate required fields
                if (string.IsNullOrWhiteSpace(maskedTextBoxID.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxFName.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxLName.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxHeight.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxWeight.Text) ||
                    string.IsNullOrWhiteSpace(comboBoxStatus.Text) ||
                    string.IsNullOrWhiteSpace(comboBoxPosition.Text))
                {
                    MessageBox.Show("Please fill in all required fields before adding an athlete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Convert height and weight
                if (!double.TryParse(txtBoxHeight.Text, out double height) ||
                    !double.TryParse(txtBoxWeight.Text, out double weight))
                {
                    MessageBox.Show("Height and Weight must be valid numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                byte[] imgData = null;
                if (pictureBoxProfileAthlete.Image != null)
                {
                    using MemoryStream ms = new MemoryStream();
                    pictureBoxProfileAthlete.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    imgData = ms.ToArray();
                }

                using SqlConnection conn = new SqlConnection(ConnectionString);
                conn.Open();

                // Check duplicate ID
                using SqlCommand chk = new SqlCommand("SELECT COUNT(1) FROM Athletes WHERE AthleteID=@id", conn);
                chk.Parameters.Add("@id", SqlDbType.VarChar).Value = maskedTextBoxID.Text.Trim();
                if (Convert.ToInt32(chk.ExecuteScalar()) > 0)
                {
                    MessageBox.Show("AthleteID already exists.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Insert athlete
                using SqlCommand cmd = new SqlCommand(@"
            INSERT INTO Athletes(AthleteID, LastName, FirstName, Age, Height, Weight, DOB, Status, Position, ProfileImage)
            VALUES (@id,@lname,@fname,@age,@height,@weight,@dob,@status,@position,@img)", conn);

                cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = maskedTextBoxID.Text.Trim();
                cmd.Parameters.Add("@lname", SqlDbType.VarChar).Value = txtBoxLName.Text.Trim();
                cmd.Parameters.Add("@fname", SqlDbType.VarChar).Value = txtBoxFName.Text.Trim();
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = (int)numericUpDownaAge.Value;
                cmd.Parameters.Add("@height", SqlDbType.Float).Value = height;
                cmd.Parameters.Add("@weight", SqlDbType.Float).Value = weight;
                cmd.Parameters.Add("@dob", SqlDbType.Date).Value = dateTimePickerDOB.Value.Date;
                cmd.Parameters.Add("@status", SqlDbType.VarChar).Value = comboBoxStatus.Text.Trim();
                cmd.Parameters.Add("@position", SqlDbType.VarChar).Value = comboBoxPosition.Text.Trim();
                cmd.Parameters.Add("@img", SqlDbType.VarBinary).Value = imgData ?? (object)DBNull.Value;

                cmd.ExecuteNonQuery();
                MessageBox.Show("Athlete added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadAthletes();
                AttendanceControlRef?.RefreshAttendance();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding athlete:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(maskedTextBoxID.Text))
            {
                MessageBox.Show("Select an athlete to update.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Validate required fields
                if (string.IsNullOrWhiteSpace(txtBoxFName.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxLName.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxHeight.Text) ||
                    string.IsNullOrWhiteSpace(txtBoxWeight.Text) ||
                    string.IsNullOrWhiteSpace(comboBoxStatus.Text) ||
                    string.IsNullOrWhiteSpace(comboBoxPosition.Text))
                {
                    MessageBox.Show("Please select an athlete before updating the athlete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Convert height and weight
                if (!double.TryParse(txtBoxHeight.Text, out double height) ||
                    !double.TryParse(txtBoxWeight.Text, out double weight))
                {
                    MessageBox.Show("Height and Weight must be valid numbers.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                byte[] imgData = null;
                if (pictureBoxProfileAthlete.Image != null)
                {
                    using MemoryStream ms = new MemoryStream();
                    pictureBoxProfileAthlete.Image.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    imgData = ms.ToArray();
                }

                using SqlConnection conn = new SqlConnection(ConnectionString);
                conn.Open();

                using SqlCommand cmd = new SqlCommand(@"
            UPDATE Athletes
            SET LastName=@lname, FirstName=@fname, Age=@age, Height=@height, Weight=@weight, DOB=@dob,
                Status=@status, Position=@position, ProfileImage=@img
            WHERE AthleteID=@id", conn);

                cmd.Parameters.Add("@id", SqlDbType.VarChar).Value = maskedTextBoxID.Text.Trim();
                cmd.Parameters.Add("@lname", SqlDbType.VarChar).Value = txtBoxLName.Text.Trim();
                cmd.Parameters.Add("@fname", SqlDbType.VarChar).Value = txtBoxFName.Text.Trim();
                cmd.Parameters.Add("@age", SqlDbType.Int).Value = (int)numericUpDownaAge.Value;
                cmd.Parameters.Add("@height", SqlDbType.Float).Value = height;
                cmd.Parameters.Add("@weight", SqlDbType.Float).Value = weight;
                cmd.Parameters.Add("@dob", SqlDbType.Date).Value = dateTimePickerDOB.Value.Date;
                cmd.Parameters.Add("@status", SqlDbType.VarChar).Value = comboBoxStatus.Text.Trim();
                cmd.Parameters.Add("@position", SqlDbType.VarChar).Value = comboBoxPosition.Text.Trim();
                cmd.Parameters.Add("@img", SqlDbType.VarBinary).Value = imgData ?? (object)DBNull.Value;

                int rows = cmd.ExecuteNonQuery();
                MessageBox.Show(rows > 0 ? "Athlete updated successfully!" : "Athlete not found.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadAthletes();
                AttendanceControlRef?.RefreshAttendance();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating athlete:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



        private void btnRemove_Click(object sender, EventArgs e)
        {
            if (dataGridViewAthletes.SelectedRows.Count == 0 ||
                string.IsNullOrWhiteSpace(maskedTextBoxID.Text))
            {
                MessageBox.Show("Please select an athlete to remove.", "Warning",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            if (MessageBox.Show("Remove this athlete and all attendance records?", "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes)
                return;

            suppressSelectionEvent = true;

            try
            {
                using SqlConnection conn = new SqlConnection(ConnectionString);
                conn.Open();
                using SqlTransaction tran = conn.BeginTransaction();

                try
                {
                    using SqlCommand cmd = new SqlCommand("DELETE FROM Attendance WHERE AthleteID=@id", conn, tran);
                    cmd.Parameters.AddWithValue("@id", maskedTextBoxID.Text.Trim());
                    cmd.ExecuteNonQuery();

                    using SqlCommand cmd2 = new SqlCommand("DELETE FROM Athletes WHERE AthleteID=@id", conn, tran);
                    cmd2.Parameters.AddWithValue("@id", maskedTextBoxID.Text.Trim());
                    cmd2.ExecuteNonQuery();

                    tran.Commit();
                }
                catch
                {
                    tran.Rollback();
                    throw;
                }

                LoadAthletes();
                AttendanceControlRef?.RefreshAttendance();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting athlete:\n{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                suppressSelectionEvent = false;
            }
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            using OpenFileDialog ofd = new OpenFileDialog { Filter = "Image Files|*.jpg;*.jpeg;*.png;*.bmp" };
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                pictureBoxProfileAthlete.Image = Image.FromFile(ofd.FileName);
            }
        }

        private void btnClearFields_Click(object sender, EventArgs e) => ClearFields();

        private void ClearFields()
        {
            maskedTextBoxID.Clear();
            txtBoxFName.Clear();
            txtBoxLName.Clear();
            txtBoxHeight.Clear();
            txtBoxWeight.Clear();
            numericUpDownaAge.Value = 0;
            comboBoxPosition.SelectedIndex = -1;
            comboBoxStatus.SelectedIndex = -1;
            pictureBoxProfileAthlete.Image = null;
            dateTimePickerDOB.Value = DateTime.Today;
        }

        private void DataGridViewAthletes_SelectionChanged(object sender, EventArgs e)
        {
            if (suppressSelectionEvent) return;
            if (dataGridViewAthletes.SelectedRows.Count == 0) return;

            var row = dataGridViewAthletes.SelectedRows[0];
            maskedTextBoxID.Text = row.Cells["AthleteID"].Value?.ToString();
            txtBoxLName.Text = row.Cells["LastName"].Value?.ToString();
            txtBoxFName.Text = row.Cells["FirstName"].Value?.ToString();
            numericUpDownaAge.Value = row.Cells["Age"].Value != null ? Convert.ToDecimal(row.Cells["Age"].Value) : 0;
            txtBoxHeight.Text = row.Cells["Height"].Value?.ToString();
            txtBoxWeight.Text = row.Cells["Weight"].Value?.ToString();
            dateTimePickerDOB.Value = DateTime.TryParse(row.Cells["DOB"].Value?.ToString(), out DateTime dt) ? dt : DateTime.Today;
            comboBoxStatus.Text = row.Cells["Status"].Value?.ToString();
            comboBoxPosition.Text = row.Cells["Position"].Value?.ToString();
            pictureBoxProfileAthlete.Image = row.Cells["ProfileImage"].Value as Image;
        }
    }
}
