﻿namespace CourtSense.User_Control
{
    partial class AttendanceControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblAttendance = new Label();
            dateTimePickerAttendacnce = new DateTimePicker();
            btnMarkAttendance = new Button();
            lblDate = new Label();
            dataGridViewMarkAttendance = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMarkAttendance).BeginInit();
            SuspendLayout();
            // 
            // lblAttendance
            // 
            lblAttendance.AutoSize = true;
            lblAttendance.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAttendance.ForeColor = Color.FromArgb(45, 71, 185);
            lblAttendance.Location = new Point(4, 13);
            lblAttendance.Margin = new Padding(4, 0, 4, 0);
            lblAttendance.Name = "lblAttendance";
            lblAttendance.Size = new Size(176, 34);
            lblAttendance.TabIndex = 2;
            lblAttendance.Text = "Attendance";
            // 
            // dateTimePickerAttendacnce
            // 
            dateTimePickerAttendacnce.CalendarForeColor = Color.FromArgb(45, 71, 185);
            dateTimePickerAttendacnce.CalendarMonthBackground = Color.White;
            dateTimePickerAttendacnce.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dateTimePickerAttendacnce.Location = new Point(64, 131);
            dateTimePickerAttendacnce.Margin = new Padding(4, 3, 4, 3);
            dateTimePickerAttendacnce.Name = "dateTimePickerAttendacnce";
            dateTimePickerAttendacnce.Size = new Size(405, 28);
            dateTimePickerAttendacnce.TabIndex = 3;
            // 
            // btnMarkAttendance
            // 
            btnMarkAttendance.BackColor = Color.FromArgb(55, 149, 189);
            btnMarkAttendance.FlatAppearance.BorderSize = 0;
            btnMarkAttendance.FlatStyle = FlatStyle.Flat;
            btnMarkAttendance.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMarkAttendance.ForeColor = Color.White;
            btnMarkAttendance.Location = new Point(738, 118);
            btnMarkAttendance.Margin = new Padding(4, 3, 4, 3);
            btnMarkAttendance.Name = "btnMarkAttendance";
            btnMarkAttendance.Size = new Size(258, 41);
            btnMarkAttendance.TabIndex = 4;
            btnMarkAttendance.Text = "Mark Attendance";
            btnMarkAttendance.UseVisualStyleBackColor = false;
            btnMarkAttendance.Click += btnMarkAttendance_Click;
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblDate.ForeColor = Color.FromArgb(45, 71, 185);
            lblDate.Location = new Point(64, 108);
            lblDate.Margin = new Padding(4, 0, 4, 0);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(47, 19);
            lblDate.TabIndex = 5;
            lblDate.Text = "Date";
            // 
            // dataGridViewMarkAttendance
            // 
            dataGridViewMarkAttendance.AllowUserToAddRows = false;
            dataGridViewMarkAttendance.AllowUserToDeleteRows = false;
            dataGridViewMarkAttendance.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewMarkAttendance.BackgroundColor = Color.White;
            dataGridViewMarkAttendance.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewMarkAttendance.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMarkAttendance.Location = new Point(64, 228);
            dataGridViewMarkAttendance.Margin = new Padding(4, 3, 4, 3);
            dataGridViewMarkAttendance.Name = "dataGridViewMarkAttendance";
            dataGridViewMarkAttendance.ReadOnly = true;
            dataGridViewMarkAttendance.RowHeadersWidth = 51;
            dataGridViewMarkAttendance.Size = new Size(932, 474);
            dataGridViewMarkAttendance.TabIndex = 6;
            // 
            // AttendanceControl
            // 
            AutoScaleDimensions = new SizeF(10F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(dataGridViewMarkAttendance);
            Controls.Add(lblDate);
            Controls.Add(btnMarkAttendance);
            Controls.Add(dateTimePickerAttendacnce);
            Controls.Add(lblAttendance);
            Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4, 3, 4, 3);
            Name = "AttendanceControl";
            Size = new Size(1044, 734);
            ((System.ComponentModel.ISupportInitialize)dataGridViewMarkAttendance).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAttendance;
        private DateTimePicker dateTimePickerAttendacnce;
        private Button btnMarkAttendance;
        private Label lblDate;
        private DataGridView dataGridViewMarkAttendance;
    }
}
