﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace CourtSense.User_Control
{
    public partial class AttendanceControl : UserControl
    {
        private const string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=CourtSenseDB;Trusted_Connection=True;";
        private DateTimePicker dtpTimeIn = new DateTimePicker();
        private DateTimePicker dtpTimeOut = new DateTimePicker();
        private int editingRowIndex = -1;
        private int editingColumnIndex = -1;

        public AttendanceControl()
        {
            InitializeComponent();
            Load += AttendanceControl_Load;
        }

        private void AttendanceControl_Load(object sender, EventArgs e)
        {
            SetupDataGrid();
            SetupDateTimePickers();

            dtpTimeIn.ValueChanged += DtpTimeIn_ValueChanged;
            dtpTimeOut.ValueChanged += DtpTimeOut_ValueChanged;

            if (dateTimePickerAttendacnce != null)
                dateTimePickerAttendacnce.ValueChanged += dtpAttendance_ValueChanged;

           // if (btnMarkAttendance != null)
             //   btnMarkAttendance.Click += btnMarkAttendance_Click;

            LoadAthletesForAttendance();
        }

        private void SetupDataGrid()
        {
            dataGridViewMarkAttendance.Columns.Clear();
            dataGridViewMarkAttendance.RowTemplate.Height = 60;
            dataGridViewMarkAttendance.AllowUserToAddRows = false;
            dataGridViewMarkAttendance.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewMarkAttendance.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridViewMarkAttendance.MultiSelect = false;
            dataGridViewMarkAttendance.EditMode = DataGridViewEditMode.EditOnEnter;

            // Hidden AthleteID
            dataGridViewMarkAttendance.Columns.Add("AthleteID", "AthleteID");
            dataGridViewMarkAttendance.Columns["AthleteID"].Visible = false;

            // Profile Image
            var imgCol = new DataGridViewImageColumn()
            {
                Name = "ProfileImage",
                HeaderText = "Profile",
                Width = 60,
                ImageLayout = DataGridViewImageCellLayout.Zoom
            };
            dataGridViewMarkAttendance.Columns.Add(imgCol);

            dataGridViewMarkAttendance.Columns.Add("LastName", "Last Name");
            dataGridViewMarkAttendance.Columns.Add("FirstName", "First Name");

            // Status ComboBox
            var statusCol = new DataGridViewComboBoxColumn()
            {
                Name = "Status",
                HeaderText = "Status",
                FlatStyle = FlatStyle.Flat,
                DisplayStyle = DataGridViewComboBoxDisplayStyle.ComboBox,
                DisplayStyleForCurrentCellOnly = true
            };
            statusCol.Items.AddRange("Present", "Absent", "Excused");
            statusCol.DefaultCellStyle.NullValue = "";
            dataGridViewMarkAttendance.Columns.Add(statusCol);

            // Time Columns
            dataGridViewMarkAttendance.Columns.Add(new DataGridViewTextBoxColumn() { Name = "TimeIn", HeaderText = "Time In" });
            dataGridViewMarkAttendance.Columns.Add(new DataGridViewTextBoxColumn() { Name = "TimeOut", HeaderText = "Time Out" });

            // Events
            dataGridViewMarkAttendance.CellBeginEdit += DataGridViewMarkAttendance_CellBeginEdit;
            dataGridViewMarkAttendance.CellClick += DataGridViewMarkAttendance_CellClick;
            dataGridViewMarkAttendance.EditingControlShowing += DataGridViewMarkAttendance_EditingControlShowing;
            dataGridViewMarkAttendance.CellEnter += DataGridViewMarkAttendance_CellEnter;
            dataGridViewMarkAttendance.CellLeave += DataGridViewMarkAttendance_CellLeave;

            dataGridViewMarkAttendance.ReadOnly = false;
        }

        private void DataGridViewMarkAttendance_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex < 0) return;

            var col = dataGridViewMarkAttendance.Columns[e.ColumnIndex];
            if (col.Name == "Status" || col.Name == "TimeIn" || col.Name == "TimeOut")
                dataGridViewMarkAttendance.BeginEdit(true);
        }

        private void DataGridViewMarkAttendance_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            var colName = dataGridViewMarkAttendance.CurrentCell?.OwningColumn?.Name;

            if (colName == "Status" && e.Control is ComboBox cb)
            {
                cb.SelectedIndexChanged -= StatusCombo_SelectedIndexChanged;
                cb.SelectedIndexChanged += StatusCombo_SelectedIndexChanged;

                cb.DroppedDown = true; // auto open
                cb.BackColor = Color.LightYellow;
                cb.FlatStyle = FlatStyle.Flat;
            }
        }

        private void StatusCombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            ComboBox combo = sender as ComboBox;
            if (combo == null) return;

            int row = dataGridViewMarkAttendance.CurrentCell.RowIndex;
            string selectedStatus = combo.SelectedItem?.ToString();

            // Clear times if Absent or Excused
            if (selectedStatus == "Absent" || selectedStatus == "Excused")
            {
                dataGridViewMarkAttendance.Rows[row].Cells["TimeIn"].Value = null;
                dataGridViewMarkAttendance.Rows[row].Cells["TimeOut"].Value = null;
            }

            dataGridViewMarkAttendance.NotifyCurrentCellDirty(true);
            dataGridViewMarkAttendance.CommitEdit(DataGridViewDataErrorContexts.Commit);
        }

        private void SetupDateTimePickers()
        {
            dtpTimeIn.Format = DateTimePickerFormat.Time;
            dtpTimeIn.ShowUpDown = true;
            dtpTimeIn.Visible = false;
            dtpTimeIn.BackColor = Color.LightYellow;

            dtpTimeOut.Format = DateTimePickerFormat.Time;
            dtpTimeOut.ShowUpDown = true;
            dtpTimeOut.Visible = false;
            dtpTimeOut.BackColor = Color.LightYellow;

            dtpTimeIn.ValueChanged += DtpTimeIn_ValueChanged;
            dtpTimeOut.ValueChanged += DtpTimeOut_ValueChanged;

            dataGridViewMarkAttendance.Controls.Add(dtpTimeIn);
            dataGridViewMarkAttendance.Controls.Add(dtpTimeOut);
        }

        private void DtpTimeIn_ValueChanged(object sender, EventArgs e)
        {
            if (editingRowIndex >= 0)
                dataGridViewMarkAttendance.Rows[editingRowIndex].Cells["TimeIn"].Value =
                    dtpTimeIn.Value.ToString("HH:mm:ss");
        }

        private void DtpTimeOut_ValueChanged(object sender, EventArgs e)
        {
            if (editingRowIndex >= 0)
                dataGridViewMarkAttendance.Rows[editingRowIndex].Cells["TimeOut"].Value =
                    dtpTimeOut.Value.ToString("HH:mm:ss");
        }

        private void DataGridViewMarkAttendance_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            if (e.RowIndex < 0) return;

            editingRowIndex = e.RowIndex;
            editingColumnIndex = e.ColumnIndex;

            dtpTimeIn.Visible = false;
            dtpTimeOut.Visible = false;

            string colName = dataGridViewMarkAttendance.Columns[e.ColumnIndex].Name;
            Rectangle rect = dataGridViewMarkAttendance.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, true);

            if (colName == "TimeIn")
            {
                dtpTimeIn.SetBounds(rect.X, rect.Y, rect.Width, rect.Height);
                dtpTimeIn.Visible = true;
                dtpTimeIn.BringToFront();
                this.BeginInvoke((MethodInvoker)(() => dtpTimeIn.Focus()));

                var val = dataGridViewMarkAttendance.Rows[e.RowIndex].Cells["TimeIn"].Value?.ToString();
                dtpTimeIn.Value = TimeSpan.TryParse(val, out TimeSpan ts) ? DateTime.Today.Add(ts) : DateTime.Now;
            }
            else if (colName == "TimeOut")
            {
                dtpTimeOut.SetBounds(rect.X, rect.Y, rect.Width, rect.Height);
                dtpTimeOut.Visible = true;
                dtpTimeOut.BringToFront();
                this.BeginInvoke((MethodInvoker)(() => dtpTimeOut.Focus()));

                var val = dataGridViewMarkAttendance.Rows[e.RowIndex].Cells["TimeOut"].Value?.ToString();
                dtpTimeOut.Value = TimeSpan.TryParse(val, out TimeSpan ts) ? DateTime.Today.Add(ts) : DateTime.Now;
            }
        }

        private void DataGridViewMarkAttendance_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            dataGridViewMarkAttendance.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.LightYellow;
        }

        private void DataGridViewMarkAttendance_CellLeave(object sender, DataGridViewCellEventArgs e)
        {
            dtpTimeIn.Visible = false;
            dtpTimeOut.Visible = false;
            editingRowIndex = -1;
            editingColumnIndex = -1;
            dataGridViewMarkAttendance.Rows[e.RowIndex].Cells[e.ColumnIndex].Style.BackColor = Color.White;
        }

        public void LoadAthletesForAttendance()
        {
            DateTime selectedDate = dateTimePickerAttendacnce?.Value.Date ?? DateTime.Today;
            dataGridViewMarkAttendance.Rows.Clear();

            try
            {
                using SqlConnection conn = new SqlConnection(ConnectionString);
                conn.Open();
                string query = @"
                    SELECT a.AthleteID, a.FirstName, a.LastName, a.ProfileImage,
                           at.Status, at.TimeIn, at.TimeOut
                    FROM Athletes a
                    LEFT JOIN Attendance at 
                      ON a.AthleteID = at.AthleteID AND at.AttendanceDate = @date
                    ORDER BY a.LastName, a.FirstName";

                using SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@date", selectedDate);
                using SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Image photo = null;
                    if (!reader.IsDBNull(3))
                    {
                        byte[] data = (byte[])reader[3];
                        using MemoryStream ms = new MemoryStream(data);
                        photo = Image.FromStream(ms);
                    }

                    dataGridViewMarkAttendance.Rows.Add(
                        reader["AthleteID"].ToString(),
                        photo,
                        reader["LastName"].ToString(),
                        reader["FirstName"].ToString(),
                        reader.IsDBNull(4) ? "" : reader["Status"].ToString(),
                        reader.IsDBNull(5) ? "" : reader["TimeIn"].ToString(),
                        reader.IsDBNull(6) ? "" : reader["TimeOut"].ToString()
                    );
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading attendance data:\n{ex.Message}");
            }
        }

        public void SaveAttendance()
        {
            DateTime selectedDate = dateTimePickerAttendacnce?.Value.Date ?? DateTime.Today;

            foreach (DataGridViewRow row in dataGridViewMarkAttendance.Rows)
            {
                if (row.IsNewRow) continue;

                string status = row.Cells["Status"].Value?.ToString();
               
                string timeInStr = row.Cells["TimeIn"].Value?.ToString();
                string timeOutStr = row.Cells["TimeOut"].Value?.ToString();

                // Skip validation for Absent / Excused
                if (status == "Absent" || status == "Excused")
                    continue;

                // If times exist, validate them
                if (!string.IsNullOrEmpty(timeInStr) && !string.IsNullOrEmpty(timeOutStr))
                {
                    DateTime timeIn = DateTime.Parse(timeInStr);
                    DateTime timeOut = DateTime.Parse(timeOutStr);

                    if (timeOut < timeIn)
                    {
                        MessageBox.Show(
                            $"Time Out cannot be earlier than Time In for row {row.Index + 1}.",
                            "Invalid Time",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Warning
                        );
                        return;
                    }
                }

            }

            try
            {
                using SqlConnection conn = new SqlConnection(ConnectionString);
                conn.Open();
                foreach (DataGridViewRow row in dataGridViewMarkAttendance.Rows)
                {
                    if (row.IsNewRow) continue;
                    string id = row.Cells["AthleteID"].Value?.ToString();
                    if (string.IsNullOrEmpty(id)) continue;

                    string status = row.Cells["Status"].Value?.ToString();
                    string timeIn = row.Cells["TimeIn"].Value?.ToString();
                    string timeOut = row.Cells["TimeOut"].Value?.ToString();

                    string query = @"
                        IF EXISTS (SELECT 1 FROM Attendance WHERE AthleteID=@id AND AttendanceDate=@date)
                            UPDATE Attendance 
                            SET Status=@status, TimeIn=@timeIn, TimeOut=@timeOut
                            WHERE AthleteID=@id AND AttendanceDate=@date
                        ELSE
                            INSERT INTO Attendance(AthleteID, AttendanceDate, Status, TimeIn, TimeOut)
                            VALUES (@id, @date, @status, @timeIn, @timeOut)";

                    using SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@date", selectedDate);
                    cmd.Parameters.AddWithValue("@status", string.IsNullOrEmpty(status) ? (object)DBNull.Value : status);
                    cmd.Parameters.AddWithValue("@timeIn", TimeSpan.TryParse(timeIn, out TimeSpan tsIn) ? (object)tsIn : DBNull.Value);
                    cmd.Parameters.AddWithValue("@timeOut", TimeSpan.TryParse(timeOut, out TimeSpan tsOut) ? (object)tsOut : DBNull.Value);
                    cmd.ExecuteNonQuery();
                }

                MessageBox.Show($"Attendance saved successfully for {selectedDate.ToShortDateString()}");
                LoadAthletesForAttendance();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving attendance:\n{ex.Message}");
            }
        }

        private void btnMarkAttendance_Click(object sender, EventArgs e) => SaveAttendance();
        private void dtpAttendance_ValueChanged(object sender, EventArgs e) => LoadAthletesForAttendance();
        public void RefreshAttendance() => LoadAthletesForAttendance();
    }
}
