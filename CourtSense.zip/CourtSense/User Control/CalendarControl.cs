﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;


namespace CourtSense.User_Control
{
    public partial class CalendarControl : UserControl
    {
        public CalendarControl()
        {
            InitializeComponent();
            this.HandleCreated += CalendarControl_Load;
        }

        private async void CalendarControl_Load(object sender, EventArgs e)
        {
            // Skip running inside the Visual Studio Designer
            if (DesignMode || LicenseManager.UsageMode == LicenseUsageMode.Designtime)
                return;

            if (webViewCalendar == null)
            {
                MessageBox.Show("webViewCalendar is not initialized!");
                return;
            }

            try
            {
                await webViewCalendar.EnsureCoreWebView2Async();

                // Ensure CoreWebView2 is ready before using it
                if (webViewCalendar.CoreWebView2 == null)
                {
                    MessageBox.Show("WebView2 failed to initialize.");
                    return;
                }

                webViewCalendar.CoreWebView2.AddHostObjectToScript("backend", new CalendarBackend());
                string htmlPath = Path.Combine(Application.StartupPath, "calendar", "calendar.html");

                if (!File.Exists(htmlPath))
                {
                    MessageBox.Show("HTML file not found: " + htmlPath);
                    return;
                }

                webViewCalendar.CoreWebView2.Navigate(htmlPath);
            }
            catch (Exception ex)
            {
                MessageBox.Show("WebView2 error: " + ex.Message);
            }
        }




    }
}

