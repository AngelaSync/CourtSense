﻿namespace CourtSense.User_Control
{
    partial class AthleteControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AthleteControl));
            lblAthlete = new Label();
            pictureBoxProfileAthlete = new PictureBox();
            txtBoxWeight = new TextBox();
            lblProfileImage = new Label();
            lblLastName = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            comboBoxPosition = new ComboBox();
            dateTimePickerDOB = new DateTimePicker();
            numericUpDownaAge = new NumericUpDown();
            maskedTextBoxID = new MaskedTextBox();
            comboBoxStatus = new ComboBox();
            txtBoxLName = new TextBox();
            txtBoxFName = new TextBox();
            btnBrowse = new Button();
            btnAdd = new Button();
            btnRemove = new Button();
            btnUpdate = new Button();
            btnClearFields = new Button();
            lblSearch = new Label();
            txtBoxSearch = new TextBox();
            btnSearch = new Button();
            dataGridViewAthletes = new DataGridView();
            txtBoxHeight = new TextBox();
            ((System.ComponentModel.ISupportInitialize)pictureBoxProfileAthlete).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownaAge).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAthletes).BeginInit();
            SuspendLayout();
            // 
            // lblAthlete
            // 
            lblAthlete.AutoSize = true;
            lblAthlete.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblAthlete.ForeColor = Color.FromArgb(45, 71, 185);
            lblAthlete.Location = new Point(2, 13);
            lblAthlete.Margin = new Padding(4, 0, 4, 0);
            lblAthlete.Name = "lblAthlete";
            lblAthlete.Size = new Size(112, 34);
            lblAthlete.TabIndex = 3;
            lblAthlete.Text = "Athlete";
            // 
            // pictureBoxProfileAthlete
            // 
            pictureBoxProfileAthlete.BorderStyle = BorderStyle.FixedSingle;
            pictureBoxProfileAthlete.Location = new Point(44, 65);
            pictureBoxProfileAthlete.Name = "pictureBoxProfileAthlete";
            pictureBoxProfileAthlete.Size = new Size(125, 122);
            pictureBoxProfileAthlete.TabIndex = 4;
            pictureBoxProfileAthlete.TabStop = false;
            // 
            // txtBoxWeight
            // 
            txtBoxWeight.BorderStyle = BorderStyle.FixedSingle;
            txtBoxWeight.Font = new Font("Century Gothic", 9F);
            txtBoxWeight.Location = new Point(379, 300);
            txtBoxWeight.Name = "txtBoxWeight";
            txtBoxWeight.Size = new Size(278, 26);
            txtBoxWeight.TabIndex = 9;
            // 
            // lblProfileImage
            // 
            lblProfileImage.AutoSize = true;
            lblProfileImage.Font = new Font("Century Gothic", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblProfileImage.Location = new Point(186, 77);
            lblProfileImage.Name = "lblProfileImage";
            lblProfileImage.Size = new Size(117, 21);
            lblProfileImage.TabIndex = 14;
            lblProfileImage.Text = "Profile Image";
            // 
            // lblLastName
            // 
            lblLastName.AutoSize = true;
            lblLastName.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblLastName.Location = new Point(44, 218);
            lblLastName.Name = "lblLastName";
            lblLastName.Size = new Size(85, 20);
            lblLastName.TabIndex = 15;
            lblLastName.Text = "Last Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(44, 277);
            label1.Name = "label1";
            label1.Size = new Size(83, 20);
            label1.TabIndex = 16;
            label1.Text = "First Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(44, 338);
            label2.Name = "label2";
            label2.Size = new Size(40, 20);
            label2.TabIndex = 17;
            label2.Text = "Age";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(379, 338);
            label3.Name = "label3";
            label3.Size = new Size(99, 20);
            label3.TabIndex = 18;
            label3.Text = "Date of Birth";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.Location = new Point(379, 277);
            label4.Name = "label4";
            label4.Size = new Size(94, 20);
            label4.TabIndex = 19;
            label4.Text = "Weight (lbs)";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.Location = new Point(379, 218);
            label5.Name = "label5";
            label5.Size = new Size(80, 20);
            label5.TabIndex = 20;
            label5.Text = "Height (ft)";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(710, 218);
            label6.Name = "label6";
            label6.Size = new Size(51, 20);
            label6.TabIndex = 21;
            label6.Text = "Status";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.Location = new Point(710, 277);
            label7.Name = "label7";
            label7.Size = new Size(64, 20);
            label7.TabIndex = 22;
            label7.Text = "Position";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.Location = new Point(710, 338);
            label8.Name = "label8";
            label8.Size = new Size(25, 20);
            label8.TabIndex = 23;
            label8.Text = "ID";
            // 
            // comboBoxPosition
            // 
            comboBoxPosition.Font = new Font("Century Gothic", 9F);
            comboBoxPosition.FormattingEnabled = true;
            comboBoxPosition.Items.AddRange(new object[] { "Setter", "Outside Hitter", "Middle Blocker", "Opposite Hitter", "Libero" });
            comboBoxPosition.Location = new Point(710, 299);
            comboBoxPosition.Name = "comboBoxPosition";
            comboBoxPosition.Size = new Size(278, 28);
            comboBoxPosition.TabIndex = 25;
            // 
            // dateTimePickerDOB
            // 
            dateTimePickerDOB.Font = new Font("Century Gothic", 9F);
            dateTimePickerDOB.Location = new Point(379, 361);
            dateTimePickerDOB.Name = "dateTimePickerDOB";
            dateTimePickerDOB.Size = new Size(278, 26);
            dateTimePickerDOB.TabIndex = 26;
            // 
            // numericUpDownaAge
            // 
            numericUpDownaAge.BorderStyle = BorderStyle.FixedSingle;
            numericUpDownaAge.Font = new Font("Century Gothic", 9F);
            numericUpDownaAge.Location = new Point(44, 361);
            numericUpDownaAge.Name = "numericUpDownaAge";
            numericUpDownaAge.Size = new Size(278, 26);
            numericUpDownaAge.TabIndex = 27;
            // 
            // maskedTextBoxID
            // 
            maskedTextBoxID.BorderStyle = BorderStyle.FixedSingle;
            maskedTextBoxID.Font = new Font("Century Gothic", 9F);
            maskedTextBoxID.Location = new Point(710, 363);
            maskedTextBoxID.Mask = "00-0000-000";
            maskedTextBoxID.Name = "maskedTextBoxID";
            maskedTextBoxID.Size = new Size(278, 26);
            maskedTextBoxID.TabIndex = 28;
            // 
            // comboBoxStatus
            // 
            comboBoxStatus.Font = new Font("Century Gothic", 9F);
            comboBoxStatus.FormattingEnabled = true;
            comboBoxStatus.Items.AddRange(new object[] { "Active", "Inactive", "Injured" });
            comboBoxStatus.Location = new Point(710, 239);
            comboBoxStatus.Name = "comboBoxStatus";
            comboBoxStatus.Size = new Size(278, 28);
            comboBoxStatus.TabIndex = 29;
            // 
            // txtBoxLName
            // 
            txtBoxLName.BorderStyle = BorderStyle.FixedSingle;
            txtBoxLName.Font = new Font("Century Gothic", 9F);
            txtBoxLName.Location = new Point(44, 241);
            txtBoxLName.Name = "txtBoxLName";
            txtBoxLName.Size = new Size(278, 26);
            txtBoxLName.TabIndex = 30;
            // 
            // txtBoxFName
            // 
            txtBoxFName.BorderStyle = BorderStyle.FixedSingle;
            txtBoxFName.Font = new Font("Century Gothic", 9F);
            txtBoxFName.Location = new Point(44, 300);
            txtBoxFName.Name = "txtBoxFName";
            txtBoxFName.Size = new Size(278, 26);
            txtBoxFName.TabIndex = 31;
            // 
            // btnBrowse
            // 
            btnBrowse.BackColor = Color.FromArgb(55, 149, 189);
            btnBrowse.FlatAppearance.BorderSize = 0;
            btnBrowse.FlatStyle = FlatStyle.Flat;
            btnBrowse.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnBrowse.ForeColor = Color.White;
            btnBrowse.Location = new Point(186, 112);
            btnBrowse.Name = "btnBrowse";
            btnBrowse.Size = new Size(117, 41);
            btnBrowse.TabIndex = 33;
            btnBrowse.Text = "Browse";
            btnBrowse.UseVisualStyleBackColor = false;
            btnBrowse.Click += btnBrowse_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(55, 149, 189);
            btnAdd.FlatAppearance.BorderSize = 0;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.ForeColor = Color.White;
            btnAdd.Location = new Point(44, 426);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(117, 41);
            btnAdd.TabIndex = 34;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnRemove
            // 
            btnRemove.BackColor = Color.FromArgb(55, 149, 189);
            btnRemove.FlatAppearance.BorderSize = 0;
            btnRemove.FlatStyle = FlatStyle.Flat;
            btnRemove.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRemove.ForeColor = Color.White;
            btnRemove.Location = new Point(186, 426);
            btnRemove.Name = "btnRemove";
            btnRemove.Size = new Size(117, 41);
            btnRemove.TabIndex = 35;
            btnRemove.Text = "REMOVE";
            btnRemove.UseVisualStyleBackColor = false;
            btnRemove.Click += btnRemove_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(55, 149, 189);
            btnUpdate.FlatAppearance.BorderSize = 0;
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.ForeColor = Color.White;
            btnUpdate.Location = new Point(323, 426);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(117, 41);
            btnUpdate.TabIndex = 36;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnClearFields
            // 
            btnClearFields.BackColor = Color.FromArgb(55, 149, 189);
            btnClearFields.FlatAppearance.BorderSize = 0;
            btnClearFields.FlatStyle = FlatStyle.Flat;
            btnClearFields.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnClearFields.ForeColor = Color.White;
            btnClearFields.Location = new Point(464, 426);
            btnClearFields.Name = "btnClearFields";
            btnClearFields.Size = new Size(117, 41);
            btnClearFields.TabIndex = 38;
            btnClearFields.Text = "CLEAR FIELDS";
            btnClearFields.UseVisualStyleBackColor = false;
            btnClearFields.Click += btnClearFields_Click;
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblSearch.Location = new Point(644, 441);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(60, 20);
            lblSearch.TabIndex = 39;
            lblSearch.Text = "Search";
            // 
            // txtBoxSearch
            // 
            txtBoxSearch.BorderStyle = BorderStyle.FixedSingle;
            txtBoxSearch.Font = new Font("Century Gothic", 9F);
            txtBoxSearch.Location = new Point(710, 435);
            txtBoxSearch.Name = "txtBoxSearch";
            txtBoxSearch.Size = new Size(234, 26);
            txtBoxSearch.TabIndex = 40;
            // 
            // btnSearch
            // 
            btnSearch.FlatStyle = FlatStyle.Flat;
            btnSearch.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSearch.Image = (Image)resources.GetObject("btnSearch.Image");
            btnSearch.Location = new Point(950, 428);
            btnSearch.Name = "btnSearch";
            btnSearch.Size = new Size(38, 38);
            btnSearch.TabIndex = 41;
            btnSearch.UseVisualStyleBackColor = true;
            // 
            // dataGridViewAthletes
            // 
            dataGridViewAthletes.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewAthletes.Location = new Point(44, 489);
            dataGridViewAthletes.Name = "dataGridViewAthletes";
            dataGridViewAthletes.RowHeadersWidth = 51;
            dataGridViewAthletes.Size = new Size(944, 228);
            dataGridViewAthletes.TabIndex = 42;
            // 
            // txtBoxHeight
            // 
            txtBoxHeight.BorderStyle = BorderStyle.FixedSingle;
            txtBoxHeight.Font = new Font("Century Gothic", 9F);
            txtBoxHeight.Location = new Point(379, 241);
            txtBoxHeight.Name = "txtBoxHeight";
            txtBoxHeight.Size = new Size(278, 26);
            txtBoxHeight.TabIndex = 32;
            // 
            // AthleteControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(dataGridViewAthletes);
            Controls.Add(btnSearch);
            Controls.Add(txtBoxSearch);
            Controls.Add(lblSearch);
            Controls.Add(btnClearFields);
            Controls.Add(btnUpdate);
            Controls.Add(btnRemove);
            Controls.Add(btnAdd);
            Controls.Add(btnBrowse);
            Controls.Add(txtBoxHeight);
            Controls.Add(txtBoxFName);
            Controls.Add(txtBoxLName);
            Controls.Add(comboBoxStatus);
            Controls.Add(maskedTextBoxID);
            Controls.Add(numericUpDownaAge);
            Controls.Add(dateTimePickerDOB);
            Controls.Add(comboBoxPosition);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(lblLastName);
            Controls.Add(lblProfileImage);
            Controls.Add(txtBoxWeight);
            Controls.Add(pictureBoxProfileAthlete);
            Controls.Add(lblAthlete);
            Name = "AthleteControl";
            Size = new Size(1044, 734);
            ((System.ComponentModel.ISupportInitialize)pictureBoxProfileAthlete).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownaAge).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridViewAthletes).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAthlete;
        private PictureBox pictureBoxProfileAthlete;
        private TextBox txtBoxWeight;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox9;
        private Label lblProfileImage;
        private Label lblLastName;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private ComboBox comboBoxStatus;
        private ComboBox comboBoxPosition;
        private DateTimePicker dateTimePickerDOB;
        private NumericUpDown numericUpDownaAge;
        private MaskedTextBox maskedTextBoxID;
        private TextBox txtBoxLName;
        private TextBox txtBoxFName;
        private Button btnBrowse;
        private Button btnAdd;
        private Button btnRemove;
        private Button btnUpdate;
        private Button btnClearFields;
        private Label lblSearch;
        private TextBox txtBoxSearch;
        private Button btnSearch;
        private DataGridView dataGridViewAthletes;
        private TextBox txtBoxHeight;
    }
}
