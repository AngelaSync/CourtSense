﻿namespace CourtSense.User_Control
{
    partial class CalendarControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            webViewCalendar = new Microsoft.Web.WebView2.WinForms.WebView2();
            lblCalendar = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)webViewCalendar).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(webViewCalendar);
            panel1.Location = new Point(3, 63);
            panel1.Name = "panel1";
            panel1.Size = new Size(1038, 659);
            panel1.TabIndex = 0;
            // 
            // webViewCalendar
            // 
            webViewCalendar.AllowExternalDrop = true;
            webViewCalendar.CreationProperties = null;
            webViewCalendar.DefaultBackgroundColor = Color.White;
            webViewCalendar.Dock = DockStyle.Fill;
            webViewCalendar.Location = new Point(0, 0);
            webViewCalendar.Name = "webViewCalendar";
            webViewCalendar.Size = new Size(1038, 659);
            webViewCalendar.TabIndex = 0;
            webViewCalendar.ZoomFactor = 1D;
            // 
            // lblCalendar
            // 
            lblCalendar.AutoSize = true;
            lblCalendar.Font = new Font("Century Gothic", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCalendar.ForeColor = Color.FromArgb(45, 71, 185);
            lblCalendar.Location = new Point(3, 11);
            lblCalendar.Name = "lblCalendar";
            lblCalendar.Size = new Size(142, 34);
            lblCalendar.TabIndex = 1;
            lblCalendar.Text = "Calendar";
            // 
            // CalendarControl
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            Controls.Add(lblCalendar);
            Controls.Add(panel1);
            Name = "CalendarControl";
            Size = new Size(1053, 747);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)webViewCalendar).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Microsoft.Web.WebView2.WinForms.WebView2 webViewCalendar;
        private Label lblCalendar;
    }
}
