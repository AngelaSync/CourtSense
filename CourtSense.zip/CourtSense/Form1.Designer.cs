﻿namespace CourtSense
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            panel1 = new Panel();
            button1 = new Button();
            btnPerformance = new Button();
            btnAthletes = new Button();
            btnAttendance = new Button();
            btnCalendar = new Button();
            panel3 = new Panel();
            panelSide = new Panel();
            panel2 = new Panel();
            lblCourtSense = new Label();
            pictureBox1 = new PictureBox();
            panelMain = new Panel();
            calendarControl1 = new CourtSense.User_Control.CalendarControl();
            panel1.SuspendLayout();
            panel3.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelMain.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(45, 71, 185);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(btnPerformance);
            panel1.Controls.Add(btnAthletes);
            panel1.Controls.Add(btnAttendance);
            panel1.Controls.Add(btnCalendar);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(258, 759);
            panel1.TabIndex = 0;
            // 
            // button1
            // 
            button1.Dock = DockStyle.Bottom;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.White;
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(8, 700);
            button1.Name = "button1";
            button1.Size = new Size(250, 59);
            button1.TabIndex = 6;
            button1.Text = "LogOut";
            button1.TextAlign = ContentAlignment.MiddleRight;
            button1.TextImageRelation = TextImageRelation.ImageBeforeText;
            button1.UseVisualStyleBackColor = true;
            // 
            // btnPerformance
            // 
            btnPerformance.Dock = DockStyle.Top;
            btnPerformance.FlatAppearance.BorderSize = 0;
            btnPerformance.FlatStyle = FlatStyle.Flat;
            btnPerformance.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPerformance.ForeColor = Color.White;
            btnPerformance.Image = (Image)resources.GetObject("btnPerformance.Image");
            btnPerformance.Location = new Point(8, 395);
            btnPerformance.Name = "btnPerformance";
            btnPerformance.Size = new Size(250, 59);
            btnPerformance.TabIndex = 5;
            btnPerformance.Text = "     Performance";
            btnPerformance.TextAlign = ContentAlignment.MiddleRight;
            btnPerformance.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnPerformance.UseVisualStyleBackColor = true;
            // 
            // btnAthletes
            // 
            btnAthletes.Dock = DockStyle.Top;
            btnAthletes.FlatAppearance.BorderSize = 0;
            btnAthletes.FlatStyle = FlatStyle.Flat;
            btnAthletes.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAthletes.ForeColor = Color.White;
            btnAthletes.Image = (Image)resources.GetObject("btnAthletes.Image");
            btnAthletes.Location = new Point(8, 336);
            btnAthletes.Name = "btnAthletes";
            btnAthletes.Size = new Size(250, 59);
            btnAthletes.TabIndex = 4;
            btnAthletes.Text = "     Athletes";
            btnAthletes.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnAthletes.UseVisualStyleBackColor = true;
            btnAthletes.Click += btnAthletes_Click;
            // 
            // btnAttendance
            // 
            btnAttendance.Dock = DockStyle.Top;
            btnAttendance.FlatAppearance.BorderSize = 0;
            btnAttendance.FlatStyle = FlatStyle.Flat;
            btnAttendance.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAttendance.ForeColor = Color.White;
            btnAttendance.Image = (Image)resources.GetObject("btnAttendance.Image");
            btnAttendance.Location = new Point(8, 277);
            btnAttendance.Name = "btnAttendance";
            btnAttendance.Size = new Size(250, 59);
            btnAttendance.TabIndex = 3;
            btnAttendance.Text = "      Attendance   ";
            btnAttendance.TextAlign = ContentAlignment.MiddleRight;
            btnAttendance.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnAttendance.UseVisualStyleBackColor = true;
            btnAttendance.Click += btnAttendance_Click;
            // 
            // btnCalendar
            // 
            btnCalendar.Dock = DockStyle.Top;
            btnCalendar.FlatAppearance.BorderSize = 0;
            btnCalendar.FlatStyle = FlatStyle.Flat;
            btnCalendar.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalendar.ForeColor = Color.White;
            btnCalendar.Image = (Image)resources.GetObject("btnCalendar.Image");
            btnCalendar.Location = new Point(8, 218);
            btnCalendar.Name = "btnCalendar";
            btnCalendar.Size = new Size(250, 59);
            btnCalendar.TabIndex = 2;
            btnCalendar.Text = "      Calendar";
            btnCalendar.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnCalendar.UseVisualStyleBackColor = true;
            btnCalendar.Click += btnCalendar_Click;
            // 
            // panel3
            // 
            panel3.Controls.Add(panelSide);
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(0, 218);
            panel3.Name = "panel3";
            panel3.Size = new Size(8, 541);
            panel3.TabIndex = 1;
            // 
            // panelSide
            // 
            panelSide.BackColor = Color.White;
            panelSide.Location = new Point(0, 0);
            panelSide.Name = "panelSide";
            panelSide.Size = new Size(8, 59);
            panelSide.TabIndex = 2;
            // 
            // panel2
            // 
            panel2.Controls.Add(lblCourtSense);
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(258, 218);
            panel2.TabIndex = 0;
            // 
            // lblCourtSense
            // 
            lblCourtSense.AutoSize = true;
            lblCourtSense.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCourtSense.ForeColor = SystemColors.ControlLightLight;
            lblCourtSense.Location = new Point(66, 142);
            lblCourtSense.Name = "lblCourtSense";
            lblCourtSense.Size = new Size(120, 23);
            lblCourtSense.TabIndex = 1;
            lblCourtSense.Text = "CourtSense";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(81, 42);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(93, 87);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panelMain
            // 
            panelMain.Controls.Add(calendarControl1);
            panelMain.Location = new Point(264, 12);
            panelMain.Name = "panelMain";
            panelMain.Size = new Size(1044, 747);
            panelMain.TabIndex = 2;
            // 
            // calendarControl1
            // 
            calendarControl1.BackColor = Color.White;
            calendarControl1.Dock = DockStyle.Fill;
            calendarControl1.Location = new Point(0, 0);
            calendarControl1.Name = "calendarControl1";
            calendarControl1.Size = new Size(1044, 747);
            calendarControl1.TabIndex = 0;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1320, 758);
            Controls.Add(panelMain);
            Controls.Add(panel1);
            Font = new Font("Microsoft Sans Serif", 8.25F);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "CourtSense";
            panel1.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelMain.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Panel panel2;
        private Label lblCourtSense;
        private PictureBox pictureBox1;
        private Button btnCalendar;
        private Panel panel3;
        private Panel panelSide;
        private Button btnPerformance;
        private Button btnAthletes;
        private Button btnAttendance;
        private Button button1;
        private Panel panelMain;
        private User_Control.CalendarControl calendarControl1;
    }
}
