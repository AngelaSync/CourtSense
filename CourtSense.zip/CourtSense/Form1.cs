﻿using CourtSense.User_Control;
using System;
using System.Windows.Forms;

namespace CourtSense
{
    public partial class Form1 : Form
    {
        private CalendarControl calendarUC = new CalendarControl();  // placeholder UC
        private AttendanceControl attendanceUC = new AttendanceControl();
        private AthleteControl athleteUC = new AthleteControl();

        public Form1()
        {
            InitializeComponent();

            // Set docking to fill the panel
            calendarUC.Dock = DockStyle.Fill;
            attendanceUC.Dock = DockStyle.Fill;
            athleteUC.Dock = DockStyle.Fill;

            // Add once to the panel
            panelMain.Controls.Add(calendarUC);
            panelMain.Controls.Add(attendanceUC);
            panelMain.Controls.Add(athleteUC);

            // Link athlete UC to attendance UC for auto-refresh
            athleteUC.AttendanceControlRef = attendanceUC;

            // Show calendar first
            calendarUC.BringToFront();
        }

        private void btnCalendar_Click(object sender, EventArgs e)
        {
            calendarUC.BringToFront();
        }

        private void btnAttendance_Click(object sender, EventArgs e)
        {
            attendanceUC.BringToFront();
        }

        private void btnAthletes_Click(object sender, EventArgs e)
        {
            athleteUC.BringToFront();
        }
    }
}
