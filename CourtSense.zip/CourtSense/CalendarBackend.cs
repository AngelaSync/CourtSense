﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text.Json;

namespace CourtSense
{
    [System.Runtime.InteropServices.ComVisible(true)]
    public class CalendarBackend
    {
        private const string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=CourtSenseDB;Trusted_Connection=True;";

        // Get all events for FullCalendar
        public string GetEventsJson()
        {
            var events = new List<object>();
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                string query = "SELECT Id, Title, EventType, StartDate, Color FROM CalendarEvents";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        events.Add(new
                        {
                            id = reader.GetInt32(0),
                            title = reader.GetString(1),
                            start = ((DateTime)reader["StartDate"]).ToString("s"), // ISO
                            color = reader["Color"].ToString(),
                            extendedProps = new { type = reader["EventType"].ToString() } // important for GUI
                        });
                    }
                }
            }
            return JsonSerializer.Serialize(events);
        }

        // Add new event
        public int AddEvent(string title, string type, string startIso, string color)
        {
            DateTime start = DateTime.Parse(startIso);
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                string query = @"
                    INSERT INTO CalendarEvents (Title, EventType, StartDate, Color)
                    VALUES (@title,@type,@start,@color);
                    SELECT SCOPE_IDENTITY();";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@type", type);
                    cmd.Parameters.AddWithValue("@start", start);
                    cmd.Parameters.AddWithValue("@color", color);
                    return Convert.ToInt32(cmd.ExecuteScalar());
                }
            }
        }

        // Update event
        public void UpdateEvent(int id, string title, string type, string startIso, string color)
        {
            DateTime start = DateTime.Parse(startIso);
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                string query = @"
                    UPDATE CalendarEvents
                    SET Title=@title, EventType=@type, StartDate=@start, Color=@color
                    WHERE Id=@id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@title", title);
                    cmd.Parameters.AddWithValue("@type", type);
                    cmd.Parameters.AddWithValue("@start", start);
                    cmd.Parameters.AddWithValue("@color", color);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // Delete event
        public void DeleteEvent(int id)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                string query = "DELETE FROM CalendarEvents WHERE Id=@id";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
            }
        }
    }
}
